1. 新建 .vim/bundle 和 .vim/colors      
2. 在bundle 中下载vundle，将solarized.vim 复制到colors中        
3. 复制vimrc 为 .vimrc 到 ～    
4. vim :PLuginInstall           
5. 等待完成吧！ Congratuations !
