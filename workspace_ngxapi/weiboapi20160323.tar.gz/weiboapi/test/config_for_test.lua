local cfg = {

        ip = 'api.daoke.io',

        -- ip = '127.0.0.1',

        -- ip = '192.168.1.3',

        port = 80,

        -- path = '/weiboapi/v2/verifyApplyJoiningMember',
        -- body = '{"appKey":"1111111111", "groupID":"pnlmBtmoFR3IFt7y", "creatorAccountID":"WFlYtlfPlg","applyAccountID":"kxl1QuHKCD","yes":1}'


        path = '/weiboapi/v2/createGroup',
        body = '{"appKey":"2582535051", "groupName":"广州林安物流", "accountID":"ou0ndc690k"}'

         -- accountID:56YnRD8n3A,  6Ej6Edzbh3, qh5jDD2EXC, kxl1QuHKCD
         -- userid:56YnRD8n3A
         -- mirrtalkNumber='13038324881'
}


return cfg
