local cfg = {

        -- ip = '192.168.1.3',

        -- ip = '113.207.96.33',

        -- ip = '221.228.229.250',
        
        -- ip = '221.228.231.86',

        ip = '127.0.0.1',

        port = 8088,

        -- path = '/v2/sendTTSOnlineWeibo',

        -- body = '{"appKey":"2064302565", "interval":123, "allowYes":1, "text":"hello world"}'


        path = '/v2/sendMultimediaOnlineWeibo',

        body = '{"appKey":"2064302565", "interval":123, "allowYes":1, "multimediaURL":"http://hello.world/j"}'


         -- accountID:56YnRD8n3A
         -- userid:56YnRD8n3A
         -- mirrtalkNumber='13038324881'
}


return cfg
