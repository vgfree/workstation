package.path = "/data/nginx/weiboapi/api/?.lua;" .. package.path
